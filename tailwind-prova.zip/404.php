<?php get_header(); ?>

<main>
<h1><?php _e( 'Pagina non trovata', 'il-mio-tema' ); ?></h1>
<p><?php _e( 'Spiacente, la pagina che cerchi non esiste.', 'il-mio-tema' ); ?></p>

</main>

<?php get_footer(); ?>

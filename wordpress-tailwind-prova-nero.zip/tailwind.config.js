module.exports = {
    content: [
      "./*.php",
      "./**/*.php"
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  